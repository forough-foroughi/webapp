var aLangKeys = Array.from({length: 2});
aLangKeys['en'] = [];
aLangKeys['fa'] = [];


aLangKeys['en']['menuHome'] = 'Home';
aLangKeys['en']['menuIntroduce'] = 'Introduce';
aLangKeys['en']['menuMore'] = 'More';
aLangKeys['en']['menuProperties'] = 'Properties';
aLangKeys['en']['menuLogin'] = 'Login';
aLangKeys['en']['menuNews'] = 'News';
aLangKeys['en']['menuHelp'] = 'Help';
aLangKeys['en']['menuService'] = 'Service';

///////////////////////////////////////////////////// home

aLangKeys['en']['homeContent'] = 'Bato';
aLangKeys['en']['homeLable'] = 'Infinite peace of mind';
aLangKeys['en']['openWebPage'] = 'Sign in to website';
aLangKeys['en']['downloadAndroidApp'] = 'download Bato application';


//////////////////////////////////////////////////// introduce

aLangKeys['en']['introduceContent'] = 'Bato is an application that aims to provide three different simultaneous experiences in a single environment.'+
    'You can send and receive all types of messages through this messenger, search for people based on their locations and send friend requests to them and also get financial services that you need.'+
    'Design, implementation and Bato’s technical engineering services is highly on point.';

///////////////////////////////////////////////////// more

aLangKeys['en']['moreLable'] = 'Why Bato?';
aLangKeys['en']['moreContent'] = 'Everything you expect from a messenger';
aLangKeys['en']['moreIdea'] = 'Sharing Opinions';
aLangKeys['en']['moreIdeaDesc'] = 'We live on the edge of sharing, now by joining different groups you can share your ideas, beliefs, impressions and point of views more widely, and also provide a platform for sharing content with your family, friends and colleagues by creating groups of your own';
aLangKeys['en']['moreNews'] = 'Aknowledging news';
aLangKeys['en']['moreNewsDesc'] = 'You can get updated on the latest news events around the world by subscribing to various news channels as well as being the news source yourself by creating channels, publishing content to them and share it with others';
aLangKeys['en']['moreFriend'] = 'Searching for friends';
aLangKeys['en']['moreFriendDesc'] = 'Finding people based on their geographical locations and sending requests in order to talk to them is one of the great features of Bato. However the Activation of this feature is based on users’ opinion so your privacy is fully protected';
aLangKeys['en']['moreServices'] = 'Submit your services';
aLangKeys['en']['moreServicesDesc'] = 'You can provide your own services in the form of Bot and present them. Normally you need the least programming knowledge in order to provide bot services with the help of bot development guides. We’ll do our best to make these platforms optimized and more convenient for you';
aLangKeys['en']['morePrivacy'] = 'privacy';
aLangKeys['en']['morePrivacyDesc'] = 'Privacy of users is one of our most great concerns. Users’ information in Bato is safeguarded due to our secure procedures and commonly as keeping the privacy of users and their trust leads to providing business, it is considered to be the most fundamental basis of service provision';
aLangKeys['en']['moreFinancial'] = 'Get Financial services';
aLangKeys['en']['moreFinancialDesc'] = 'You can benefit from predefined services in the form of Bots. these services provide you developments and particular platforms day by day. We intend to increase the number of services more often and simplify your access to them.';

///////////////////////////////////////////////////// properties

aLangKeys['en']['propertiesLable'] = 'Bato messenger, infinite feature';
aLangKeys['en']['propertiesFunctional'] = 'Development of core services based on functional languages';
aLangKeys['en']['propertiesIntegrated'] = 'Cloud integrated development ';
aLangKeys['en']['propertiesCloud'] = 'Providing services in private cloud platforms';
aLangKeys['en']['propertiesWhiteHat'] = 'Holding security competitions in white hat system and providing awards for bugs';
aLangKeys['en']['propertiesImage'] = 'Send and receive text, photos, videos';
aLangKeys['en']['propertiesGroup'] = 'Create and provide channel and group services';
aLangKeys['en']['propertiesReceiveService'] = 'Receive services in the form of Bot';
aLangKeys['en']['propertiesSendService'] = 'Provide your own services with Bot';
aLangKeys['en']['propertiesFriend'] = 'Searching for friends';

///////////////////////////////////////////////////// service

aLangKeys['en']['serviceLable'] = 'Bato messenger, infinite companion';
aLangKeys['en']['privacy--message'] = 'All rights reserved for Bato';
aLangKeys['en']['telephone'] = 'Phone: 88527939';
aLangKeys['en']['email'] = 'Email: bato@chmail.ir';
aLangKeys['en']['serviceGroup'] = 'Bato Support: ';
///////////////////////////////////////////////////////////////////////////////////////////////////////////////// fa

aLangKeys['fa']['menuHome'] = 'خانه';
aLangKeys['fa']['menuIntroduce'] = 'معرفی';
aLangKeys['fa']['menuMore'] = 'بیشتر';
aLangKeys['fa']['menuProperties'] = 'ویژگی ها';
aLangKeys['fa']['menuLogin'] = 'ورود';
aLangKeys['fa']['menuNews'] = 'اخبار';
aLangKeys['fa']['menuHelp'] = 'راهنما';
aLangKeys['fa']['menuService'] = 'پشتیبانی';

///////////////////////////////////////////////////// home

aLangKeys['fa']['homeContent'] = 'باتو';
aLangKeys['fa']['homeLable'] = 'بی نهایت آرامش در ارتباط';
aLangKeys['fa']['openWebPage'] = 'ورود به نسخه وب';
aLangKeys['fa']['downloadAndroidApp'] = 'دانلود اپلیکیشن باتو';

//////////////////////////////////////////////////// introduce

aLangKeys['fa']['introduceContent'] = 'باتو یک نرم افزار است که قصد دارد سه تجربه همزمان را در یک محیط واحد را برای شما فراهم آورد.'
    + ' در این نرم افزار شما می توانید با مخاطبان خود، ارسال و دریافت همزمان اطلاعات و پیام داشته باشید ، همچنین براساس موقعیت جغرافیایی افراد را جستجو و درخواست آشنایی و صحبت ارسال کنید و در نهایت سرویس های مالی مورد نیاز خود را دریافت کنید.'+
    'یکی از مهمترین موضوعات در خصوص مجموعه سرویس ها و سامانه های باتو ، طراحی ، پیاده سازی و پشتیبانی توسط تیم فنی و مهندسی مجموعه باتو است . ';

///////////////////////////////////////////////////// more

aLangKeys['fa']['moreLable'] = 'چرا باتو؟';
aLangKeys['fa']['moreContent'] = 'هرآنچه از یک پیام‌رسان انتظار دارید';
aLangKeys['fa']['moreIdea'] = 'به اشتراک گذاری نظرات';
aLangKeys['fa']['moreIdeaDesc'] = 'شما با عضویت در گروه های مختلف می توانید نظرات خود را به اشتراک گذارید ، البته شما در صورت تمایل می توانید با ساخت گروه های مختلف بستر اشتراک نظر برای دوستان و همکاران و یا خانواده خود را ایجاد کنید.';
aLangKeys['fa']['moreNews'] = 'اطلاع از اخبار';
aLangKeys['fa']['moreNewsDesc'] = 'در باتو شما می توانید با عضو شدن در کانال های مختلف خبری و اطلاع رسانی از اخرین اخبار روز آگاه شوید ، همچنین می توانید شما منبع نشر و اطلاع رسانی اخبار باشید.';
aLangKeys['fa']['moreFriend'] = 'جستوجوی دوستان';
aLangKeys['fa']['moreFriendDesc'] = 'در باتو شما می توانید براساس منطقه جغرافیایی افراد را جستجو و برای آن ها درخواست آشنایی ارسال نمایید ، البته فعال سازی / غیر فعال سازی این قابلیت براساس نظر کاربر است و حریم خصوصی کاربر کاملا حفاظت شده است.';
aLangKeys['fa']['moreServices'] = 'ارایه خدمات شما';
aLangKeys['fa']['moreServicesDesc'] = 'در باتو شما می توانید سرویس های خود را در بستر بات فراهم و به ارایه سرویس بپردازید ، به صورت طبیعی شما نیاز به حداقل دانش هایی از برنامه نویسی دارید تا با استفاده از راهنمای توسعه بات سروی خود را فراهم و به کاربران خود ارایه نمایید ، ما هرچه بیشتر تلاش می کنیم تا این بسترها را برای شما آسان تر و بهینه نماییم.';
aLangKeys['fa']['morePrivacy'] = 'دریافت خدمات مالی';
aLangKeys['fa']['morePrivacyDesc'] = 'در باتو شما می توانید از سرویس های از پیش تعریف شده به صورت بات استفاده نمایید ، این سرویس ها روزانه توسعه و بسترهای مختلفی را برای شما فراهم می کند ، ما قصد داریم تا هرچه بیشتر سرویس ها را افزایش و دسترسی به خدمات را برای شما آسان تر کنیم.';
aLangKeys['fa']['moreFinancial'] = 'حفظ حریم خصوصی';
aLangKeys['fa']['moreFinancialDesc'] = 'در باتو یکی از مهمترین قوانین حفظ حریم خصوصی کاربران است . اطلاعات کاربران در باتو توجه به رویه های امن حفاظت می شود و به صورت طبیعی با توجه به اینکه حفظ حریم خصوصی کاربران ، اعتماد آن ها و در نتیجه کسب و کار سرویس را فراهم می کند اصلی ترین پایه ارایه سرویس محسوب می شود.';

///////////////////////////////////////////////////// properties

aLangKeys['fa']['propertiesLable'] = 'پیام رسان باتو، بی نهایت ویژگی';
aLangKeys['fa']['propertiesFunctional'] = 'توسعه هسته خدمات براساس زبان های تابعی (Functional)';
aLangKeys['fa']['propertiesIntegrated'] = 'توسعه نرم افزارها به صورت Cloud Integrated';
aLangKeys['fa']['propertiesCloud'] = 'ارایه سرویس در بستر Private Cloud';
aLangKeys['fa']['propertiesWhiteHat'] = 'برگزاری مسابقات امنیتی در سامانه کلاه سفید و ارایه جوایز برای باگ ها';
aLangKeys['fa']['propertiesImage'] = 'ارسال و دریافت متن ، عکس ، فیلم';
aLangKeys['fa']['propertiesGroup'] = 'ساخت و ارایه خدمات کانال و گروه';
aLangKeys['fa']['propertiesReceiveService'] = 'دریافت خدمات در بستر بات';
aLangKeys['fa']['propertiesSendService'] = 'ارایه خدمات شما در بستر بات';
aLangKeys['fa']['propertiesFriend'] = 'جستجوی دوستان';

///////////////////////////////////////////////////// service

aLangKeys['fa']['serviceLable'] = 'پیام رسان باتو، بی نهایت همراهی';
aLangKeys['fa']['privacy--message'] = 'تمامی حقوق برای باتو محفوظ است';
aLangKeys['fa']['telephone'] = 'تلفن: 88527939';
aLangKeys['fa']['email'] = 'پست الکترونیک: bato@chmail.ir';
aLangKeys['fa']['serviceGroup'] = 'پشتبانی باتو: ';

var lang = 'fa'
$(document).ready(function () {

    // onclick behavior
    $('.lang').click(function () {
        lang = $(this).attr('id'); // obtain language id
        $('.parent--content').css('direction',lang === 'en'? 'ltr':'rtl')
        if (lang === 'en'){
            $('.info--serviceParent').addClass('text-left')
            $('body').addClass('english')
        } else {
            $('.info--serviceParent').removeClass('text-left')
            $('body').removeClass('english')
        }
        for (var i in document.querySelectorAll('.mySlides')) {
            $('#mySlides'+i).attr('src', './images/tablet.'+ i + '.' + lang +'.png');
        }
        for (var j in document.querySelectorAll('.mySlides--properties')) {
            $('#SlidesProperties'+j).attr('src', './images/properties/img-'+ j + '-' + lang +'.png');
        }
        // translate all translatable elements
        $('.tr').each(function (i) {
            $(this).text(aLangKeys[lang][$(this).attr('key')]);
        });

    });
    $('#firstPage').fadeOut(1500, function() {
        $('#secondPage').fadeIn(500);
    });
    var menu = document.querySelector('#scroll');
    scrollSpy(menu, 1);
});

$(".menuClick").on("click", function (e) {
    var bodyClass = document.querySelectorAll('#mainMenu .active')[0].classList;
    bodyClass.remove('active');
    $(this).addClass('active')
});

function openNav() {
    document.getElementById("myNav").style.height = "100%";
}

function closeNav() {
    document.getElementById("myNav").style.height = "0%";
}
const classOfProperties = {
    propertiesImg: $('#properiesImg'),
    WhiteHat: $('.WhiteHat img'),
    Image: $('.Image img'),
    Group: $('.Group img'),
    ReceiveService: $('.ReceiveService img'),
    Friend: $('.Friend img'),
    SendService: $('.SendService img'),
    Cloud: $('.Cloud img'),
    Integrated: $('.Integrated img'),
    Functional: $('.Functional img')
}
//////////////////////////////////////////properties
$("#properties .animationClass").hover(function () {
    var propertiesId = $(this)[0].classList
    var changeImg = false
    for (var classname of propertiesId) {
        switch (classname) {
            case "Friend":
                classOfProperties.propertiesImg.attr('src', './images/properties/img-7-'+lang+'.png');
                classOfProperties.Friend.attr('src', './images/properties/14.png');
                changeImg = true
                break
            case "SendService":
                classOfProperties.propertiesImg.attr('src', './images/properties/img-9.png');
                classOfProperties.SendService.attr('src', './images/properties/13.png');
                changeImg = true
                break
            case "ReceiveService":
                classOfProperties.propertiesImg.attr('src', './images/properties/img-6-'+lang+'.png');
                classOfProperties.ReceiveService.attr('src', './images/properties/12.png');
                changeImg = true
                break
            case "Group":
                classOfProperties.propertiesImg.attr('src', './images/properties/img-1-'+lang+'.png');
                classOfProperties.Group.attr('src', './images/properties/11.png');
                changeImg = true
                break
            case "Image":
                classOfProperties.propertiesImg.attr('src', './images/properties/img-5-'+lang+'.png');
                classOfProperties.Image.attr('src', './images/properties/10.png');
                changeImg = true
                break
            case "WhiteHat":
                classOfProperties.propertiesImg.attr('src', './images/properties/img-2.png');
                classOfProperties.WhiteHat.attr('src', './images/properties/17.png');
                changeImg = true
                break
            case "Cloud":
                classOfProperties.propertiesImg.attr('src', './images/properties/img-4.png');
                classOfProperties.Cloud.attr('src', './images/properties/16.png');
                changeImg = true
                break
            case "Integrated":
                classOfProperties.propertiesImg.attr('src', './images/properties/img-3.png');
                classOfProperties.Integrated.attr('src', './images/properties/15.png');
                changeImg = true
                break
            case "Functional":
                classOfProperties.propertiesImg.attr('src', './images/properties/img-8.png');
                classOfProperties.Functional.attr('src', './images/properties/18.png');
                changeImg = true
                break
            default:
                classOfProperties.Functional.attr('src', './images/properties/9.png');
                classOfProperties.Integrated.attr('src', './images/properties/6.png');
                classOfProperties.Cloud.attr('src', './images/properties/7.png');
                classOfProperties.WhiteHat.attr('src', './images/properties/8.png');
                classOfProperties.Image.attr('src', './images/properties/1.png');
                classOfProperties.Group.attr('src', './images/properties/2.png');
                classOfProperties.ReceiveService.attr('src', './images/properties/3.png');
                classOfProperties.SendService.attr('src', './images/properties/4.png');
                classOfProperties.Friend.attr('src', './images/properties/5.png');
        }
        if (changeImg) {
            break
        }
    }
})

var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}
    x[myIndex-1].style.display = "block";
    setTimeout(carousel, 9000);
}

window.requestAnimFrame = (function () {
    return window.requestAnimationFrame ||
        window.webkitRequestAnimationFrame ||
        window.mozRequestAnimationFrame ||
        function (callback) {
            window.setTimeout(callback, 1000 / 60);
        };
})();

var firstAnimation = function () {
    classOfProperties.propertiesImg.each(
        function () {
            $(this).delay(10).animate({
                opacity: 1,
                width: '320px',
                maxWidth: '400px'
            }, 2000);
        }
    );
};
var secondAnimation = function () {
    $('.method:eq(0)').delay(300).animate({
            opacity: 1
        }, 'slow'
    );

    $('.method:eq(1)').delay(500).animate({
            opacity: 1
        }, 'slow'
    );

    $('.method:eq(2)').delay(700).animate({
            opacity: 1
        }, 'slow',
    );

    $('.method:eq(3)').delay(900).animate({
            opacity: 1
        }, 'slow',
    );
    $('.method:eq(4)').delay(1100).animate({
            opacity: 1
        }, 'slow',
    );
    $('.method:eq(5)').delay(1300).animate({
            opacity: 1
        }, 'slow',
    );
    $('.method:eq(6)').delay(1500).animate({
            opacity: 1
        }, 'slow',
    );
    $('.method:eq(7)').delay(1700).animate({
            opacity: 1
        }, 'slow',
    );
};
var thirdAnimation = function () {
    $('.image--properties:nth-child(1)').addClass('right--animation')
    $('.image--properties:nth-child(3)').addClass('left--animation')
};


function scrollToY(scrollTargetY, speed, easing) {
    var scrollY = window.scrollY || document.documentElement.scrollTop,
        currentTime = 0;
    scrollTargetY = scrollTargetY || 0;
    speed = speed || 2000;
    easing = easing || 'easeOutSine';

    var time = Math.max(0.1, Math.min(Math.abs(scrollY - scrollTargetY) / speed, 0.8));

    var easingEquations = {

        easeOutSine: function (pos) {
            return Math.sin(pos * (Math.PI / 2));
        }
    };

    function tick() {

        currentTime += 1 / 60;

        var p = currentTime / time;
        var t = easingEquations[easing](p);

        if (p < 1) {
            requestAnimFrame(tick);
            window.scrollTo(0, scrollY + ((scrollTargetY - scrollY) * t));

        } else {
            window.scrollTo(0, scrollTargetY);
        }
    }

    tick();
}


function menuControl(menu) {
    var scrollPos = window.scrollY || document.documentElement.scrollTop,
        links = menu.querySelectorAll('.menuTag[href^="#"]');

    for (var i = 0; i < links.length; i++) {
        var currLink = links[i],
            refElement = document.querySelector(currLink.getAttribute('href'));

        if (refElement.offsetTop - 55 <= scrollPos && (refElement.offsetTop + refElement.clientHeight - 55) > scrollPos) {
            currLink.classList.add('active');

        } else {
            currLink.classList.remove('active');
        }
        if (refElement.offsetTop - 850 <= scrollPos && (refElement.offsetTop + refElement.clientHeight - 850) > scrollPos) {
            switch (i) {
                case (1):
                    $('#introduce .v-center').addClass('displayFidein')
                    break;
                case (2):
                    $('#more .v-center').addClass('displayFidein')
                    setTimeout(function () {
                        secondAnimation();
                    }, 200);
                    break;
                case (3):
                    $('#properties .animate--box').addClass('displayFidein')
                    firstAnimation();
                    thirdAnimation();
                    if (showProperties) {
                        showSlides();
                    }
                    showProperties = false
                    break;
                case (4):
                    $('#news .cd-main-content').addClass('displayFidein')
                    break;
                case (6):
                    $('.slider').addClass('animation--style')
                    $('#help').addClass('displayFidein')
                    $('.point.opacity--animate').addClass('displayFidein')
                    break;
            }
        }
    }
}


function animated(menu, speed, easing) {

    var i, links = menu.querySelectorAll('.menuTag[href^="#"]');

    function control(e) {

        e.preventDefault();

        var target = document.querySelector(this.hash);
        scrollToY(target.offsetTop, speed, easing);
    }

    for (i = 0; i < links.length; i++) {

        var link = links[i];
        if (link.classList.contains('menuTag')) {
            link.addEventListener('click', control);
        }

    }
}


function scrollSpy(menu, speed, easing) {

    animated(menu, speed, easing);
    document.addEventListener('scroll', function () {
        menuControl(menu);
    });
}


var slideIndex = 0;
var showProperties = true
var slides,dots;

function plusSlides(position) {
    slideIndex += position;
    if (slideIndex > slides.length) {slideIndex = 1}
    else if(slideIndex < 1){slideIndex = slides.length}
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");

    }
    slides[slideIndex-1].style.display = "grid";
    dots[slideIndex-1].className += " active";
}

function currentSlide(index) {
    if (index > slides.length) {index = 1}
    else if(index < 1){index = slides.length}
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[index-1].style.display = "grid";
    dots[index-1].className += " active";
    slideIndex = index
}

function showSlides() {
    var i;
    slides = document.getElementsByClassName("mySlides--properties");
    dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex> slides.length) {slideIndex = 1}
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "grid";
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 5000); // Change image every 3 seconds
}
